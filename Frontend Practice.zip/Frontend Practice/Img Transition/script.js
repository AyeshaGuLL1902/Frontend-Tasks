var imgBox = document.querySelector(".img-box");
var imageWrap = document.querySelector(".image-wrap");
var originalImg = document.getElementById("originalImg");
var line = document.getElementById("line");

originalImg.style.width = imgBox.offsetWidth + "px";

var leftSpace = imgBox.offsetLeft;

imgBox.onmousemove = function(e){
    var boxWidth = (e.pageX - leftSpace) + "px";
    imageWrap.style.width = boxWidth;
    line.style.display = boxWidth;
}

