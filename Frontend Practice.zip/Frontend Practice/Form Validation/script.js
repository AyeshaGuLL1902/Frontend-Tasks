 var nameError = document.getElementById('name-error');
 var phoneError = document.getElementById('phone-error');
 var emailError = document.getElementById('email-error');
 var msgError = document.getElementById('msg-error');
 var submitError = document.getElementById('submit-error');

function validateName(){
    var name = document.getElementById('contactName').value;
     
    if(name.length == 0){
        nameError.innerHTML = 'Name is required';
        return false;
    }
    if(!name.match(/^[A-Za-z]*\s{1}[A-Za-z]*$/)){
        nameError.innerHTML = 'Write Full Name';
        return false;
    }
    nameError.innerHTML = '<i class="fa-solid fa-circle-check"></i>';
    return true;
}

function validatePhone(){
    var phone = document.getElementById('contactPhone').value;

    if(phone.length == 0){
        phoneError.innerHTML = 'Phone no is required';
        return false;
    }
    if(phone.length !== 11){
        phoneError.innerHTML = 'Phone no should be 11 digits';
        return false;
    }
    if(!phone.match(/^[0-9]{11}$/)){
        phoneError.innerHTML = 'Only digits please';
        return false;
    }
    phoneError.innerHTML = '<i class="fas fa-check-circle"></i>';
    return true;
}

function validateEmail(){
    var email = document.getElementById('contactEmail').value;

    if(email.length == 0){
        emailError.innerHTML = 'email is required';
        return false;
    }
    if(!email.match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)){
        emailError.innerHTML = 'Invalid email';
        return false;
    }
    emailError.innerHTML = '<i class="fas fa-check-circle"></i>';
    return true;
}


function validateMsg(){
    var msg = document.getElementById('Msg').value;
    var required = 30;
    var left = required - msg.length;

    if(left > 0){
        msgError.innerHTML = left  + 'more chracters are required';
        return false;
    }
    msgError.innerHTML = '<i class="fas fa-check-circle"></i>';
    return true;
}

function validateForm(){

    submitError.style.display = 'block';
    if(!validateName() || !validatePhone() || !validateEmail() || !validateMsg() ){
        submitError.innerHTML = 'Please fix error to submit';
        setTimeout(function(){submitError.style.display = 'none'},3000);
        return false;
    }
}


