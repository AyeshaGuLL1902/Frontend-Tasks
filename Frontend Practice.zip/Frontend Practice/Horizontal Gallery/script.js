let scrollGallery = document.querySelector(".gallery");
let backBtn = document.getElementById("backBtn");
let nextBtn = document.getElementById("nextBtn");


scrollGallery.addEventListener("wheel", (e) =>{
    e.preventDefault();
    scrollGallery.scrollLeft += e.deltaY;
    // scrollGallery.style.scrollBehavior = "auto";
});

nextBtn.addEventListener("click", ()=>{
    scrollGallery.style.scrollBehavior = "smooth";
    scrollGallery.scrollLeft += 900;
});

backBtn.addEventListener("click", ()=>{
    scrollGallery.style.scrollBehavior = "smooth";
    scrollGallery.scrollLeft -= 900;
})