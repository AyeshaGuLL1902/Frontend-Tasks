const questions = [
    {
        question: "Which is the largerst country in the world?",
        answers: [
            {text: "China" , correct: false},
            {text: "Russia" , correct: true},
            {text: "Australia" , correct: false},
            {text: "America" , correct: false},
        ]
    },
    {
        question: "Who is the founder of Pakistan?",
        answers: [
            {text: "Allama Iqbal" , correct: false},
            {text: "Andrew" , correct: false},
            {text: "Quiad e Azam" , correct: true},
            {text: "Gandhi" , correct: false},
        ]
    },
    {
        question: "Which country has the largest mountian?",
        answers: [
            {text: "Mount Everst" , correct: true},
            {text: "K2" , correct: false},
            {text: "Nanga Parbat" , correct: false},
            {text: "ST1" , correct: false},
        ]
    },
    {
        question: "How many sub-continents are there in the world?",
        answers: [
            {text: "3" , correct: false},
            {text: "7" , correct: false},
            {text: "5" , correct: true},
            {text: "8" , correct: false},
        ]
    },
    {
        question: "What is the national game of Pakistan?",
        answers: [
            {text: "Hockey" , correct: false},
            {text: "Cricket" , correct: false},
            {text: "FootBall" , correct: false},
            {text: "Tenis" , correct: false},
        ]
    },


]

const QuestionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextbutton = document.getElementById("next-button");

let currentQuestionIndex = 0;
let score = 0;

function StartQuiz(){
    currentQuestionIndex = 0;
    score = 0;
    nextbutton.innerHtml = "Next";
    showQuestion();
}

function showQuestion(){
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionNo = currentQuestion + 1;
    QuestionElement.innerHTML = questionNo + "." + currentQuestion.question;

    currentQuestion.answers.forEach(answer => {
        const button = document.createElement("button");
        button.innerHTML = answer.text;
        button.classList.add("btn");
        answerButtons.appendChild(button);
        if(answer.correct)
        {
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click", SelectAnswer);
    })
}

function resetState(){
    nextbutton.style.display = "none";
    while(answerButtons.firstChild){
        answerButtons.removeChild(answerButtons.firstChild);
    }
}

function SelectAnswer(e){
    const selectedBtn = e.target;
    const iscorrect = selectedBtn.dataset.correct === "true";
    if(iscorrect){
        selectedBtn.classList.add("correct");
        score++;
    }
    else{
        selectedBtn.classList.add("incorrect");
    }
    Array.from(answerButtons.children).forEach(button => {
        if(button.dataset.correct === "true"){
            button.classList.add("correct");          
        }
        button.disabled = true;
    } );s

    nextbutton.style.display  = "block";
}

function showScore(){
    resetState();
    QuestionElement.innerHTML = "You Scored ${score} out of ${questions.length}!";
    nextbutton.innerHTML = "Play Again";
    nextbutton.style.display = "block";
}

function handleNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex < questions.length){
        showQuestion();
    }else{
        showScore();
    }
}

nextbutton.addEventListener("click", () => {
    if(currentQuestionIndex < questions.length)
    {
        handleNextButton();
    }else{
        StartQuiz();
    }
})

StartQuiz();